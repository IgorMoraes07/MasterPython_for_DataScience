# demonstrate the logging api in Python

# TODO: use the built-in logging module


# TODO: Use basicConfig to configure logging

# TODO: Try out each of the log levels

# TODO: Output formatted strings to the log


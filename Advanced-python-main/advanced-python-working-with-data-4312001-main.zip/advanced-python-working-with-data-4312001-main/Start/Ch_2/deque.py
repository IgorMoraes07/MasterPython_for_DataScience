# deque objects are like double-ended queues

import collections
import string


# TODO: initialize a deque with lowercase letters

# TODO: deques support the len() function

# TODO: deques can be iterated over

# TODO: manipulate items from either end

# TODO: use an index to get a particular item

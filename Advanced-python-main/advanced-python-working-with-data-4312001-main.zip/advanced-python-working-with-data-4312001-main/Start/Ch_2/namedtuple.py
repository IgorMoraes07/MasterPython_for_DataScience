# Demonstrate the usage of namdtuple objects

import collections


# TODO: create a Point namedtuple

# TODO: use _replace to create a new instance
